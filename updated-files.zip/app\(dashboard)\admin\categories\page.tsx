'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { FolderEdit, Check, AlertCircle, Image as ImageIcon, ArrowLeft, Trash2 } from 'lucide-react';
import { useCMS } from '@/lib/cms-store';
import ImageUploadInput from '@/components/ImageUploadInput';

export default function AdminCategoriesPage() {
  const { categories, updateCategory, deleteCategory, loaded } = useCMS();
  const categoriesList = Object.values(categories);

  const [selectedSlug, setSelectedSlug] = useState('classic-match');
  const activeCategory = categories[selectedSlug] || categories['classic-match'];

  const [name, setName] = useState(activeCategory?.name || '');
  const [section, setSection] = useState(activeCategory?.section || '');
  const [bannerImage, setBannerImage] = useState(activeCategory?.bannerImage || '');
  const [avatarImage, setAvatarImage] = useState(activeCategory?.avatarImage || '');
  const [description, setDescription] = useState(activeCategory?.description || '');
  const [customRules, setCustomRules] = useState(activeCategory?.customRules || '');
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Synchronize form fields when user switches category OR when CMS finishes loading
  const currentCat = categories[selectedSlug];
  useEffect(() => {
    if (currentCat) {
      setName(currentCat.name || '');
      setSection(currentCat.section || '');
      setBannerImage(currentCat.bannerImage || '');
      setAvatarImage(currentCat.avatarImage || '');
      setDescription(currentCat.description || '');
      setCustomRules(currentCat.customRules || '');
    }
  }, [selectedSlug, loaded, currentCat?.updatedAt]);

  const handleSelectCategory = (slug: string) => {
    setSelectedSlug(slug);
    const cat = categories[slug];
    if (cat) {
      setName(cat.name);
      setSection(cat.section);
      setBannerImage(cat.bannerImage);
      setAvatarImage(cat.avatarImage);
      setDescription(cat.description);
      setCustomRules(cat.customRules || '');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateCategory(selectedSlug, {
        name,
        section,
        bannerImage,
        avatarImage,
        description,
        customRules,
      });
      setToast({ text: `Category "${name}" updated successfully!`, type: 'success' });
    } catch {
      setToast({ text: `Failed to update category`, type: 'error' });
    } finally {
      setIsSaving(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!selectedSlug) return;
    const confirmDelete = window.confirm(
      `আপনি কি নিশ্চিত যে "${name || selectedSlug}" ক্যাটাগরি ডিলিট করতে চান?\nAre you sure you want to delete this category? This action cannot be undone.`
    );
    if (!confirmDelete) return;

    setIsDeleting(true);
    try {
      await deleteCategory(selectedSlug);
      setToast({ text: `Category "${name || selectedSlug}" deleted successfully!`, type: 'success' });
      const remainingSlugs = Object.keys(categories).filter((s) => s !== selectedSlug);
      if (remainingSlugs.length > 0) {
        handleSelectCategory(remainingSlugs[0]);
      }
    } catch {
      setToast({ text: 'Failed to delete category', type: 'error' });
    } finally {
      setIsDeleting(false);
      setTimeout(() => setToast(null), 3500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed top-4 right-4 z-50 p-4 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold transition-all ${
            toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
          }`}
        >
          {toast.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{toast.text}</span>
        </div>
      )}

      {/* Header */}
      <div className="pb-4 border-b border-gray-200 dark:border-white/10">
        <h1 className="text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2">
          <FolderEdit className="w-6 h-6 text-red-600" />
          Categories, Banners & Images Editor
        </h1>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
          Configure tournament category names, section headers, banner artwork, and thumbnail icons.
        </p>
      </div>

      {/* Category Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {categoriesList.map((cat) => (
          <button
            key={cat.slug}
            onClick={() => handleSelectCategory(cat.slug)}
            className={`p-3 rounded-xl border text-center transition-all ${
              selectedSlug === cat.slug
                ? 'border-red-600 bg-red-50 dark:bg-red-950/40 ring-2 ring-red-500'
                : 'border-gray-200 dark:border-white/10 hover:border-red-400 bg-white dark:bg-[#12121a]'
            }`}
          >
            <div className="w-10 h-10 rounded-full mx-auto overflow-hidden mb-1.5 border border-white/20 bg-slate-800">
              <img src={cat.avatarImage || cat.bannerImage || '/logo.png'} alt={cat.name} className="w-full h-full object-cover" />
            </div>
            <span className="text-[11px] font-black block truncate text-gray-900 dark:text-white">
              {cat.name}
            </span>
            <span className="text-[9px] text-gray-500 uppercase block truncate">{cat.section}</span>
          </button>
        ))}
      </div>

      {/* Edit Form */}
      <div className="rounded-2xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#12121a] p-6 shadow-sm">
        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                Category Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-black/30 text-xs font-bold focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                Section Title
              </label>
              <input
                type="text"
                required
                value={section}
                onChange={(e) => setSection(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-black/30 text-xs font-bold focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Banner Image Upload */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-500">Banner Artwork</span>
                <button
                  type="button"
                  onClick={() => {
                    const def = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=640';
                    setBannerImage(def);
                    setAvatarImage(def);
                  }}
                  className="text-[10px] font-bold text-red-600 hover:underline"
                >
                  Restore Default
                </button>
              </div>
              <ImageUploadInput
                label="Category Banner (Main Photo)"
                value={bannerImage}
                onChange={(url) => {
                  setBannerImage(url);
                  if (!avatarImage || avatarImage === bannerImage || avatarImage.includes('unsplash')) {
                    setAvatarImage(url);
                  }
                }}
                helperText="Upload image from device or drag-and-drop file"
              />
            </div>

            {/* Avatar Icon Upload */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-500">Icon Thumbnail</span>
                <button
                  type="button"
                  onClick={() => {
                    const def = 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=120';
                    setAvatarImage(def);
                  }}
                  className="text-[10px] font-bold text-red-600 hover:underline"
                >
                  Restore Default
                </button>
              </div>
              <ImageUploadInput
                label="Circular Thumbnail / Avatar"
                value={avatarImage}
                onChange={(url) => {
                  setAvatarImage(url);
                  if (!bannerImage || bannerImage === avatarImage || bannerImage.includes('unsplash')) {
                    setBannerImage(url);
                  }
                }}
                isCircular={true}
                helperText="Upload circular avatar icon for category list"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
              Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-black/30 text-xs font-medium focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
              Category-Specific Rules & Guidelines
            </label>
            <textarea
              rows={3}
              placeholder="Enter special instructions or tournament rules for this category..."
              value={customRules}
              onChange={(e) => setCustomRules(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-black/30 text-xs font-medium focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={handleDelete}
              disabled={isDeleting || isSaving}
              className="w-full sm:w-auto px-5 py-3 rounded-xl text-xs font-bold text-red-600 bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/60 border border-red-200 dark:border-red-900/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>{isDeleting ? 'Deleting Category...' : 'Delete Category (ক্যাটাগরি ডিলিট)'}</span>
            </button>

            <button
              type="submit"
              disabled={isSaving || isDeleting}
              className="w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-black btn-red shadow-md shadow-red-600/30 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isSaving ? 'Saving Category...' : 'Save Category Information'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
